create definer = coursera_meta@localhost view orderslargerthan200 as
select `littlelemondb`.`customers`.`CustomerID`                                                     AS `CustomerID`,
       concat(`littlelemondb`.`customers`.`FirstName`, ' ', `littlelemondb`.`customers`.`LastName`) AS `Full Name`,
       `littlelemondb`.`orders`.`OrderID`                                                           AS `OrderID`,
       `littlelemondb`.`orders`.`TotalCost`                                                         AS `Cost`,
       `littlelemondb`.`menu`.`Name`                                                                AS `Menu Name`,
       `littlelemondb`.`menuitem`.`Course`                                                          AS `Course`
from (((`littlelemondb`.`orders` join `littlelemondb`.`customers` on ((`littlelemondb`.`orders`.`CustomerID` =
                                                                       `littlelemondb`.`customers`.`CustomerID`))) join `littlelemondb`.`menu`
       on ((`littlelemondb`.`orders`.`MenuID` = `littlelemondb`.`menu`.`MenuID`))) join `littlelemondb`.`menuitem`
      on ((`littlelemondb`.`menu`.`MenuItemID` = `littlelemondb`.`menuitem`.`MenuItemID`)))
where (`littlelemondb`.`orders`.`TotalCost` > 200);

