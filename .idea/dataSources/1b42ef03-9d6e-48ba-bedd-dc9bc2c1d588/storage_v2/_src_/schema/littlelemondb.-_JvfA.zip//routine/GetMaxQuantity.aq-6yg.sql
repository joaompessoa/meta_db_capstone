create
    definer = coursera_meta@localhost procedure GetMaxQuantity()
BEGIN
    SELECT max(orders.quantity) AS 'Max Quantity In Orders'
    FROM orders;
END;

