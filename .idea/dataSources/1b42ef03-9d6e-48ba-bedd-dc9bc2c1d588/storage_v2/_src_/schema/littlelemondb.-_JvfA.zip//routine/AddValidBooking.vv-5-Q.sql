create
    definer = coursera_meta@localhost procedure AddValidBooking(IN date_booking date, IN table_no int)
BEGIN
    DECLARE booking_status VARCHAR(255);
    IF NOT EXISTS (SELECT 1 FROM bookings WHERE DATE(Date) = date_booking AND TableNo = table_no) THEN

        INSERT INTO bookings (Date, TableNo) VALUES (date_booking, table_no);
        SET booking_status = CONCAT('Table ', table_no, ' is free, booking confirmed');
        COMMIT;
    ELSE
        ROLLBACK;
        SET booking_status = CONCAT('Table ', table_no, ' is already booked, booking canceled');
    END IF;
    SELECT booking_status AS 'Booking Status';
END;

