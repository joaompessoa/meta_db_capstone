create
    definer = coursera_meta@localhost procedure CheckBooking(IN date_of_booking date, IN table_number int)
BEGIN
   DECLARE table_status varchar(40);
   IF (SELECT NOT EXISTS(SELECT DATE(bookings.DATE),bookings.tableno FROM bookings
                         WHERE date(bookings.Date) = date_of_booking AND bookings.TableNo = table_number))
        THEN SET table_status = 'Free';
   ELSE SET table_status = 'Booked';
   END IF;
   SELECT CONCAT('Table ',table_number, ' is ', table_status,' on ', date_of_booking) as 'Booking Status';
END;

