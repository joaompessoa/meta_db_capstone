create definer = coursera_meta@localhost view orderedtwiceormore as
select `littlelemondb`.`menu`.`Name` AS `Name`
from (`littlelemondb`.`menuitem` join `littlelemondb`.`menu`
      on ((`littlelemondb`.`menu`.`MenuItemID` = `littlelemondb`.`menuitem`.`MenuItemID`)))
where `littlelemondb`.`menu`.`MenuID` in (select `littlelemondb`.`orders`.`Quantity`
                                          from `littlelemondb`.`orders`
                                          where (`littlelemondb`.`orders`.`Quantity` >= 2));

