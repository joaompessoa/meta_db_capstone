create
    definer = coursera_meta@localhost procedure UpdateBooking(IN booking_id int, IN date_booking datetime)
BEGIN
    IF EXISTS(SELECT bookings.BookingID from bookings WHERE BookingID = booking_id) THEN
        UPDATE bookings SET date = date_booking WHERE BookingID = booking_id;
        SELECT CONCAT('Booking: ', booking_id, ' Was updated') As Confirmation;
    ELSE
        SELECT 'Booking doesnt exists' AS Warning;
    END IF;
END;

