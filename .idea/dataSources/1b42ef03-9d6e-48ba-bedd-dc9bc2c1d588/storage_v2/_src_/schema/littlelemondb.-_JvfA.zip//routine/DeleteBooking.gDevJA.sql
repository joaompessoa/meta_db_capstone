create
    definer = coursera_meta@localhost procedure DeleteBooking(IN booking_id int)
BEGIN
    IF EXISTS(SELECT bookings.BookingID from bookings WHERE BookingID = booking_id) THEN
        DELETE FROM bookings WHERE BookingID = booking_id;
        SELECT CONCAT('Booking: ', booking_id, ' Was Removed') As Confirmation;
    ELSE
        SELECT 'Booking doesnt exists' AS Warning;
    END IF;
END;

