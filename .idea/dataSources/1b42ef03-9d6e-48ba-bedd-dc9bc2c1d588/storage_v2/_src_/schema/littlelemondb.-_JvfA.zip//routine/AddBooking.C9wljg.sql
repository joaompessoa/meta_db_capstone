create
    definer = coursera_meta@localhost procedure AddBooking(IN date_booking datetime, IN table_no int)
BEGIN
    INSERT INTO bookings(date,tableno)
    VALUES (date_booking,table_no);
    SET @last_booking_id = LAST_INSERT_ID();
    INSERT INTO customers(FirstName,lastname,phone, email,bookingid)
    VALUES('Bob','Silva','0980980','email@example.com',@last_booking_id);
    SELECT 'New Booking Added' AS Confirmation;
END;

