create definer = coursera_meta@localhost view ordersview as
select `littlelemondb`.`orders`.`OrderID`   AS `orderid`,
       `littlelemondb`.`orders`.`Quantity`  AS `quantity`,
       `littlelemondb`.`orders`.`TotalCost` AS `totalcost`
from `littlelemondb`.`orders`
where (`littlelemondb`.`orders`.`Quantity` > 2);

