create
    definer = coursera_meta@localhost procedure CancelOrder(IN userinput int, OUT confirmation varchar(100))
BEGIN
    IF (SELECT EXISTS (SELECT OrderID FROM orders WHERE OrderID = userinput)) THEN
        DELETE FROM orders WHERE orders.OrderID = userinput;
        SET confirmation = CONCAT('Order ', userinput, 'was canceled');
    ELSE SET confirmation = CONCAT('Order ', userinput, 'doesnt exist');
    END IF;
    SELECT confirmation as 'Confirmation Message';
END;

